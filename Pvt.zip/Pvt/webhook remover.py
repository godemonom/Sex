import telebot

TOKEN = '7173557633:AAEtBEsNDBpiJ0BOM0FzA1FtmcBJQu3uzW8'
bot = telebot.TeleBot(TOKEN)

# Remove any existing webhooks
bot.remove_webhook()

# Define your message handlers and other bot logic here
@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Howdy, how are you doing?")

# Start polling
bot.polling()